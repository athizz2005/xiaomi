#ifndef __INIT_COMMON__H__
#define __INIT_COMMON__H__

void load_common_properties();
void property_override(char const prop[], char const value[], bool add = true);

#endif
