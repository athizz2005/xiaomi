#include <log/log.h>

int __android_log_print(int prio, const char* tag, const char* fmt, ...) {
  return 0;
}
