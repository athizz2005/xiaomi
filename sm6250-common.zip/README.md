Copyright (C) 2020 - The LineageOS Project

Common device tree for Xiaomi SM6250 based devices
==============
